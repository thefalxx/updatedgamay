<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../dist/output.css" rel="stylesheet">
    <title>Scan N Savor</title>
</head>
<body>
    <section>
        <nav class="  bg-white border-gray-200 dark:bg-teal-900">
            <div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="#" class="flex items-center">
                <img src="../images/Spoon___Fork_Logo-removebg-preview.png" class="h-10 mr-3" alt="Flowbite Logo" />
                <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Scan N Savor</span>
            </a>
            <div class="flex md:order-2">
                <button type="button" class="text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 text-center mr-3 md:mr-0 dark:bg-teal-600 dark:hover:bg-teal-700 dark:focus:ring-teal-800">
                    <a href="../src/login.php">Login</a></button>
                <button data-collapse-toggle="navbar-cta" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-cta" aria-expanded="false">
                  <span class="sr-only">Open main menu</span>
                  <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                      <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"/>
                  </svg>
              </button>
            </div>
            <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-cta">
              <ul class="flex flex-col font-medium p-4 md:p-0 mt-4 border md:flex-row md:space-x-8 md:mt-0 md:border-0">
                <li>
                  <a href="#home" class="block py-2 pl-3 pr-4 text-white bg-teal-700 rounded md:bg-transparent md:text-teal-700 md:p-0 md:dark:text-teal-500" aria-current="page">Home</a>
                </li>
                <li>
                  <a href="#about" class="block py-2 pl-3 pr-4 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0 md:dark:hover:text-teal-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">About</a>
                </li>
                <li>
                  <a href="#service" class="block py-2 pl-3 pr-4 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-teal-700 md:p-0 md:dark:hover:text-teal-500 dark:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700">Services</a>
                </li>
              </ul>
            </div>
            </div>
          </nav>
    </section>

    <section id="home">
        <div class="flex flex-wrap items-center font-sans px-4 mx-auto w-full lg:max-w-screen-lg sm:max-w-screen-sm md:max-w-screen-md pt-20 pb-20 pl-20">
        <!-- Column-1 -->
            <div class="px-3 w-full lg:w-2/5">
                <div
                    class="mx-auto mb-8 max-w-lg text-center lg:mx-0 lg:max-w-md lg:text-left">
                    <h2 class="mb-4 text-3xl font-bold text-left lg:text-5xl">
                        Dine with QR Technology:  

                        <span class="text-5xl text-teal-800 leading-relaxeds"
                            >Scan N Savor
                        </span>

                        
                    </h2>

                    <p class="visible mx-0 mt-3 mb-0 text-sm leading-relaxed text-left text-slate-400">
                        Maximize operations restaurant management with digitization
                    </p>
                </div>

                <div class="text-center lg:text-left">
                    <a
                        class="block visible py-4 px-8 mb-4 text-xs font-semibold tracking-wide leading-none text-white bg-teal-800 hover:bg-teal-900 rounded cursor-pointer sm:mr-3 sm:mb-0 sm:inline-block"
                        href="../src/signup.php"
                        >Get Started</a
                    >

                    <a 
                        class="block visible py-4 px-8 text-xs font-semibold leading-none bg-white hover:bg-gray-200 rounded border border-solid cursor-pointer sm:inline-block border-slate-200 text-slate-500"
                        href="../src/login.php"
                        >How We Work?</a
                    >
                </div>
            </div>

                <!-- Column-2 -->
            <div class="px-3 mb-12 w-full lg:mb-0 lg:w-3/5">
                <!-- Illustrations Container -->
                <div class="flex justify-center items-center">

                    <img src="../images/ee17dfb827a8930850e4d9b265cf9c4c-removebg-preview 1 (1).png"
                        class="block max-w-full h-auto align-middle lg:max-w-lg">
                        
                </div>
            </div>

        </div>
    </section>

    <section id="about">
        <div  class="flex flex-col w-full h-[540px] bg-cover bg-fixed bg-center justify-center items-start pl-20"
        style="
            background: url(../images/Group\ 109.png);
        ">
        <h1 class="text-white text-5xl font-semibold mt-20 mb-10">
            Looking for some place to dine in?
        </h1>

        <h3 class="text-white text-md font-thin mt-10 mb-10 pb-20">
            Lorem ipsum dolor sit amet consectetur adipiscing elit
            <br> sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            <br>Lorem ipsum dolor sit amet consectetur adipiscing elit
            <br> sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            <br> Lorem ipsum dolor sit amet consectetur adipiscing elit
            <br> sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            
        </h3>


    </section>

    <!-- <section id="service">

        <div>
            <div class="flex flex-col justify-center items-end pt-20 pl-20 pr-36">
                <h1 class="text-black text-5xl text-center font-semibold mb-10">
                    Try it yourself!
                    <br>
                    Experience innovation in your food
                </h1>
    
            </div>
        </div>

        <div>
            <div class="flex flex-col justify-center items-end pt-20 pl-20 pr-36 mr-20">
                <h4>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                    <br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                    <br>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                    <br>aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in 
                    <br>voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint 
                    <br>occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </h4>
            </div>
        </div>

            <div>
                <img src="../images/Group 87 (1).png" 
                alt="image"
                class="pl-20">
                <div class="items-center pl-20 ml-20 pb-20">
                <h4 class="text-gray-400">
                    Scan QR to view menu 
                </h4>
                </div> 
                
            </div>
    </section> -->

    <!-- service section -->

    <section id="service" class="flex flex-col md:flex-row justify-between items-center md:items-stretch">

        <div class="flex flex-col justify-center items-center md:items-start pb-20 pt-20">
            <img src="../images/Group 87 (1).png" alt="image" class="pl-20">
            <div class="items-center pl-20 ml-20">
                <h4 class="text-gray-400">
                    Scan QR to view menu 
                </h4>
            </div> 
        </div>

        <div class="flex flex-col justify-center items-center pt-10 pb-10 px-10 md:pr-36">
            <h1 class="text-black text-5xl text-center font-semibold mb-10">
                Try it yourself!
                <br>
                Experience innovation in your food
            </h1>

            <h4 class="text-black text-center font-normal">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, 
                <br>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                <br>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                <br>aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in 
                <br>voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint 
                <br>occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </h4>
        </div>
    </section>
    

    <section>
        <footer class="bottom-0 left-0 z-20 w-full p-4 bg-white border-t border-gray-200 shadow md:flex md:items-center md:justify-between md:p-6 dark:bg-teal-800 dark:border-teal-600">
            <span class="text-sm text-white sm:text-center">© 2023 
                <a href="https://flowbite.com/" 
                class="hover:underline">Scan N' Savor
                </a> 
                | IT_Capstone | All Rights Reserved.
            </span>
        </footer>
    </section>
</body>
</html>