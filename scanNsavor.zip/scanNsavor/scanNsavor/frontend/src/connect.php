<?php

$con=new mysqli('localhost', 'root', '', 'scannsavor');

if(!$con){
    die(mysqli_error($con));
}

?>